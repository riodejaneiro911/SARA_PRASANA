<?php

session_start();

include "../model/koneksi.php";

// Cek apakah yang login adalah admin
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../view/login.php");
    exit;
}

// Cek apakah data dikirim
if (!isset($_POST['id_aspirasi']) || !isset($_POST['status'])) {
    header("Location: ../view/dashboard_admin.php");
    exit;
}

$id_aspirasi = $_POST['id_aspirasi'];
$status = $_POST['status'];
$keterangan = $_POST['keterangan'] ?? '';


// Validasi status
$status_valid = ['Menunggu', 'Diproses', 'Selesai'];

if (!in_array($status, $status_valid)) {
    echo "<script>
        alert('Status tidak valid!');
        window.location='../view/dashboard_admin.php';
    </script>";
    exit;
}


// Ambil id admin dari session
$id_admin = $_SESSION['id_admin'];

$tanggal_history = date('Y-m-d');


// Update status aspirasi
$query_update = mysqli_prepare($koneksi, "
    UPDATE aspirasi
    SET status = ?
    WHERE id_aspirasi = ?
");

mysqli_stmt_bind_param(
    $query_update,
    "si",
    $status,
    $id_aspirasi
);

$berhasil_update = mysqli_stmt_execute($query_update);

mysqli_stmt_close($query_update);


// Jika update berhasil, simpan history
if ($berhasil_update) {

    $query_history = mysqli_prepare($koneksi, "
        INSERT INTO history
        (id_aspirasi, id_admin, status, keterangan, tanggal_history)
        VALUES (?, ?, ?, ?, ?)
    ");

    mysqli_stmt_bind_param(
        $query_history,
        "iisss",
        $id_aspirasi,
        $id_admin,
        $status,
        $keterangan,
        $tanggal_history
    );

    $berhasil_history = mysqli_stmt_execute($query_history);

    mysqli_stmt_close($query_history);


    if ($berhasil_history) {

        echo "<script>
            alert('Status dan history berhasil disimpan!');
            window.location='../view/dashboard_admin.php';
        </script>";

    } else {

        echo "Status berhasil diubah, tetapi history gagal disimpan: "
            . mysqli_error($koneksi);

    }

} else {

    echo "Gagal mengubah status: " . mysqli_error($koneksi);

}

?>