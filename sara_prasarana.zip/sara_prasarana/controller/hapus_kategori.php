<?php

session_start();

include "../model/koneksi.php";

// Cek login admin
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../view/login.php");
    exit;
}

// Cek ID kategori
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../view/kategori.php");
    exit;
}

$id_kategori = intval($_GET['id']);

// Hapus kategori
$query = mysqli_query(
    $koneksi,
    "DELETE FROM kategori WHERE id_kategori = $id_kategori"
);

// Cek hasil
if ($query) {
    header("Location: ../view/kategori.php");
    exit;
} else {
    echo "Kategori tidak bisa dihapus.<br>";
    echo "Error: " . mysqli_error($koneksi);
}
?>