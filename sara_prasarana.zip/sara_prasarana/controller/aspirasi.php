<?php

session_start();

include "../model/koneksi.php";


// Cek apakah yang login adalah siswa
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'siswa') {
    header("Location: ../view/login.php");
    exit;
}


// Cek apakah semua data dikirim
if (
    !isset($_POST['id_kategori']) ||
    !isset($_POST['judul']) ||
    !isset($_POST['isi_aspirasi'])
) {
    echo "<script>
        alert('Data pengaduan belum lengkap!');
        window.location='../view/pengaduan.php';
    </script>";
    exit;
}


$id_siswa = $_SESSION['id_siswa'];
$id_kategori = $_POST['id_kategori'];
$judul = trim($_POST['judul']);
$isi_aspirasi = trim($_POST['isi_aspirasi']);


// Cek data tidak boleh kosong
if ($id_kategori == '' || $judul == '' || $isi_aspirasi == '') {

    echo "<script>
        alert('Semua data pengaduan wajib diisi!');
        window.location='../view/pengaduan.php';
    </script>";
    exit;
}


// ============================
// PROSES FOTO
// ============================

$nama_foto = NULL;

// Kalau siswa memilih foto
if (isset($_FILES['foto']) && $_FILES['foto']['error'] != UPLOAD_ERR_NO_FILE) {

    // Cek apakah upload berhasil
    if ($_FILES['foto']['error'] != UPLOAD_ERR_OK) {

        echo "<script>
            alert('Foto gagal diupload!');
            window.location='../view/pengaduan.php';
        </script>";
        exit;
    }


    // Ambil informasi file
    $nama_asli = $_FILES['foto']['name'];
    $tmp_foto = $_FILES['foto']['tmp_name'];
    $ukuran_foto = $_FILES['foto']['size'];


    // Ambil ekstensi file
    $ekstensi = strtolower(
        pathinfo($nama_asli, PATHINFO_EXTENSION)
    );


    // Format yang diperbolehkan
    $ekstensi_valid = ['jpg', 'jpeg', 'png'];


    // Cek format
    if (!in_array($ekstensi, $ekstensi_valid)) {

        echo "<script>
            alert('Format foto harus JPG, JPEG, atau PNG!');
            window.location='../view/pengaduan.php';
        </script>";
        exit;
    }


    // Batas ukuran 2 MB
    if ($ukuran_foto > 2 * 1024 * 1024) {

        echo "<script>
            alert('Ukuran foto maksimal 2 MB!');
            window.location='../view/pengaduan.php';
        </script>";
        exit;
    }


    // Buat nama file baru agar tidak bentrok
    $nama_foto = uniqid('foto_') . '.' . $ekstensi;


    // Lokasi penyimpanan
    $folder_upload = "../uploads/";

    $lokasi_foto = $folder_upload . $nama_foto;


    // Pindahkan foto ke folder uploads
    if (!move_uploaded_file($tmp_foto, $lokasi_foto)) {

        echo "<script>
            alert('Foto gagal disimpan!');
            window.location='../view/pengaduan.php';
        </script>";
        exit;
    }
}


// Data tambahan
$tanggal = date('Y-m-d');
$status = "Menunggu";


// Simpan pengaduan
$query = mysqli_prepare($koneksi, "
    INSERT INTO aspirasi
    (id_siswa, id_kategori, judul, isi_aspirasi, foto, tanggal, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");

mysqli_stmt_bind_param(
    $query,
    "iisssss",
    $id_siswa,
    $id_kategori,
    $judul,
    $isi_aspirasi,
    $nama_foto,
    $tanggal,
    $status
);


$berhasil = mysqli_stmt_execute($query);

mysqli_stmt_close($query);


// Hasil
if ($berhasil) {

    echo "<script>
        alert('Pengaduan berhasil dikirim!');
        window.location='../view/dashboard_siswa.php';
    </script>";

} else {

    // Kalau database gagal, hapus foto yang sudah terupload
    if ($nama_foto != NULL && file_exists("../uploads/" . $nama_foto)) {
        unlink("../uploads/" . $nama_foto);
    }

    echo "Pengaduan gagal disimpan: " . mysqli_error($koneksi);

}

?>