<?php

session_start();

include "../model/koneksi.php";

// Cek apakah yang login adalah admin
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: ../view/login.php");
    exit;
}

// Cek apakah data dikirim
if (!isset($_POST['nama_kategori'])) {
    header("Location: ../view/kategori.php");
    exit;
}

// Ambil dan bersihkan data
$nama_kategori = trim($_POST['nama_kategori']);

// Cek apakah kosong
if ($nama_kategori == '') {
    header("Location: ../view/kategori.php");
    exit;
}

// Cek apakah kategori sudah ada
$cek = mysqli_prepare(
    $koneksi,
    "SELECT id_kategori FROM kategori WHERE nama_kategori = ?"
);

mysqli_stmt_bind_param($cek, "s", $nama_kategori);
mysqli_stmt_execute($cek);
mysqli_stmt_store_result($cek);

if (mysqli_stmt_num_rows($cek) > 0) {
    mysqli_stmt_close($cek);

    echo "Kategori sudah ada.";
    echo "<br><br>";
    echo "<a href='../view/kategori.php'>Kembali ke Kelola Kategori</a>";
    exit;
}

mysqli_stmt_close($cek);

// Simpan kategori
$stmt = mysqli_prepare(
    $koneksi,
    "INSERT INTO kategori (nama_kategori) VALUES (?)"
);

mysqli_stmt_bind_param($stmt, "s", $nama_kategori);

if (mysqli_stmt_execute($stmt)) {

    mysqli_stmt_close($stmt);

    header("Location: ../view/kategori.php");
    exit;

} else {

    echo "Gagal menambahkan kategori.";
    echo "<br><br>";
    echo "<a href='../view/kategori.php'>Kembali ke Kelola Kategori</a>";

    mysqli_stmt_close($stmt);
    exit;
}