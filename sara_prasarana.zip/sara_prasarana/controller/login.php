<?php

session_start();

include "../model/koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];

// Cek login admin
$query_admin = mysqli_query($koneksi, 
    "SELECT * FROM admin 
     WHERE username='$username' 
     AND password='$password'"
);

if (mysqli_num_rows($query_admin) > 0) {

    $admin = mysqli_fetch_assoc($query_admin);

    $_SESSION['login'] = true;
    $_SESSION['role'] = "admin";
    $_SESSION['id_admin'] = $admin['id_admin'];
    $_SESSION['nama'] = $admin['nama'];
    $_SESSION['username'] = $admin['username'];

    header("Location: ../view/dashboard_admin.php");
    exit;
}


// Cek login siswa
$query_siswa = mysqli_query($koneksi, 
    "SELECT * FROM siswa 
     WHERE username='$username' 
     AND password='$password'"
);

if (mysqli_num_rows($query_siswa) > 0) {

    $siswa = mysqli_fetch_assoc($query_siswa);

    $_SESSION['login'] = true;
    $_SESSION['role'] = "siswa";
    $_SESSION['id_siswa'] = $siswa['id_siswa'];
    $_SESSION['nama'] = $siswa['nama'];
    $_SESSION['nis'] = $siswa['nis'];
    $_SESSION['kelas'] = $siswa['kelas'];
    $_SESSION['username'] = $siswa['username'];

    header("Location: ../view/dashboard_siswa.php");
    exit;
}


// Jika login gagal
echo "<script>
    alert('Username atau password salah!');
    window.location='../view/login.php';
</script>";

?>