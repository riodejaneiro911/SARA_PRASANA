<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login - Sarana Aspirasi</title>

    <link rel="stylesheet" href="../asset/css/style.css">

    <style>
        .login-form input[type="text"],
        .login-form input[type="password"] {
            display: block;
            width: 100%;
            height: 46px;
            box-sizing: border-box;
            padding: 13px 15px;
            margin: 0;
            border: 1px solid #c1dce9;
            border-radius: 12px;
            background: #fbfdff;
            color: #262d38;
            font-family: Arial, sans-serif;
            font-size: 14px;
            line-height: normal;
            outline: none;
        }

        .login-form input[type="text"]:focus,
        .login-form input[type="password"]:focus {
            border-color: #39abf6;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(57, 171, 246, 0.15);
        }
    </style>

</head>

<body>

    <div class="container">

        <div class="header">

            <h2>Login Sarana Aspirasi</h2>

            <p>
                Silakan masuk untuk melanjutkan.
            </p>

        </div>

        <div class="card">

            <form
                action="../controller/login.php"
                method="POST"
                class="login-form"
            >

                <label class="label">
                    Username
                </label>

                <input
                    type="text"
                    name="username"
                    required
                >

                <br><br>

                <label class="label">
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    required
                >

                <br><br>

                <button type="submit">
                    Login
                </button>

            </form>

        </div>

    </div>

</body>

</html>