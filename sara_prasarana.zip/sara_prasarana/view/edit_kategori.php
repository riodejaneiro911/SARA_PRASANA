<?php

session_start();

include "../model/koneksi.php";

// Cek apakah yang login adalah admin
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Cek ID kategori
if (!isset($_GET['id'])) {
    header("Location: kategori.php");
    exit;
}

$id_kategori = $_GET['id'];

// Ambil data kategori
$stmt = mysqli_prepare(
    $koneksi,
    "SELECT nama_kategori FROM kategori WHERE id_kategori = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id_kategori);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

// Kalau kategori tidak ditemukan
if (!$data) {
    echo "Kategori tidak ditemukan.";
    echo "<br><br>";
    echo "<a href='kategori.php'>Kembali</a>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Kategori</title>

    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>

    <div class="container">

        <div class="header">

            <h2>Edit Kategori</h2>

            <p>
                Ubah nama kategori pengaduan.
            </p>

        </div>

        <div class="card">

            <form
                action="../controller/edit_kategori.php"
                method="POST"
            >

                <input
                    type="hidden"
                    name="id_kategori"
                    value="<?php echo $id_kategori; ?>"
                >

                <label class="label">
                    Nama Kategori
                </label>

                <input
                    type="text"
                    name="nama_kategori"
                    value="<?php echo htmlspecialchars($data['nama_kategori']); ?>"
                    required
                >

                <button type="submit">
                    Simpan Perubahan
                </button>

            </form>

            <a class="back" href="kategori.php">
                ← Batal
            </a>

        </div>

    </div>

</body>

</html>