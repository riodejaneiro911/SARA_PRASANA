<?php

session_start();

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'siswa') {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard Siswa</title>

    <link rel="stylesheet" href="../asset/css/style.css">

    <style>
        .menu-siswa {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .menu-item {
            display: block;
            padding: 20px;
            border-radius: 16px;
            background: #f2f9fd;
            border: 1px solid #c1e5fc;
            color: #17547d;
            text-decoration: none;
            text-align: center;
            font-weight: bold;
            font-size: 15px;
            transition: 0.2s;
        }

        .menu-item:hover {
            background: #e0f0fa;
            border-color: #39abf6;
            transform: translateY(-2px);
        }

        .menu-item.logout {
            background: #fff5f5;
            border-color: #ffdede;
            color: #d95353;
        }

        .menu-item.logout:hover {
            background: #ffeaea;
            border-color: #e05252;
        }

        @media (max-width: 600px) {

            .menu-siswa {
                grid-template-columns: 1fr;
            }

            .menu-item {
                padding: 17px;
            }

        }
    </style>

</head>

<body>

<div class="container">

    <div class="header">

        <h2>Dashboard Siswa</h2>

        <p>
            Selamat datang,
            <b><?php echo $_SESSION['nama']; ?></b>
        </p>

    </div>

    <div class="card">

        <h3>Menu</h3>

        <div class="menu-siswa">

            <a href="pengaduan.php" class="menu-item">
                Buat Pengaduan
            </a>

            <a href="riwayat.php" class="menu-item">
                Riwayat Pengaduan
            </a>

            <a href="../controller/logout.php" class="menu-item logout">
                Logout
            </a>

        </div>

    </div>

</div>

</body>

</html>