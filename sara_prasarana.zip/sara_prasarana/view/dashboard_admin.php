<?php

session_start();

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include "../model/koneksi.php";

/*
|--------------------------------------------------------------------------
| Statistik
|--------------------------------------------------------------------------
*/

$query_total = mysqli_query($koneksi, "
    SELECT COUNT(*) AS total
    FROM aspirasi
");

$data_total = mysqli_fetch_assoc($query_total);
$total_pengaduan = $data_total['total'];

$query_menunggu = mysqli_query($koneksi, "
    SELECT COUNT(*) AS total
    FROM aspirasi
    WHERE status = 'Menunggu'
");

$data_menunggu = mysqli_fetch_assoc($query_menunggu);
$total_menunggu = $data_menunggu['total'];

$query_diproses = mysqli_query($koneksi, "
    SELECT COUNT(*) AS total
    FROM aspirasi
    WHERE status = 'Diproses'
");

$data_diproses = mysqli_fetch_assoc($query_diproses);
$total_diproses = $data_diproses['total'];

$query_selesai = mysqli_query($koneksi, "
    SELECT COUNT(*) AS total
    FROM aspirasi
    WHERE status = 'Selesai'
");

$data_selesai = mysqli_fetch_assoc($query_selesai);
$total_selesai = $data_selesai['total'];

/*
|--------------------------------------------------------------------------
| Statistik Per Kategori
|--------------------------------------------------------------------------
*/

$query_statistik_kategori = mysqli_query($koneksi, "
    SELECT 
        kategori.nama_kategori,
        COUNT(aspirasi.id_aspirasi) AS total
    FROM kategori
    LEFT JOIN aspirasi
        ON kategori.id_kategori = aspirasi.id_kategori
    GROUP BY kategori.id_kategori, kategori.nama_kategori
    ORDER BY total DESC, kategori.nama_kategori ASC
");

/*
|--------------------------------------------------------------------------
| Filter
|--------------------------------------------------------------------------
*/

$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$filter_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

/*
|--------------------------------------------------------------------------
| Ambil daftar kategori
|--------------------------------------------------------------------------
*/

$query_kategori = mysqli_query($koneksi, "
    SELECT *
    FROM kategori
    ORDER BY nama_kategori ASC
");

/*
|--------------------------------------------------------------------------
| Query pengaduan
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT 
        aspirasi.*,
        siswa.nama AS nama_siswa,
        siswa.nis,
        siswa.kelas,
        kategori.nama_kategori
    FROM aspirasi
    JOIN siswa 
        ON aspirasi.id_siswa = siswa.id_siswa
    JOIN kategori 
        ON aspirasi.id_kategori = kategori.id_kategori
    WHERE 1=1
";

/*
|--------------------------------------------------------------------------
| Filter Status
|--------------------------------------------------------------------------
*/

if ($filter_status != '') {
    $filter_status = mysqli_real_escape_string($koneksi, $filter_status);

    $sql .= " AND aspirasi.status = '$filter_status'";
}

/*
|--------------------------------------------------------------------------
| Filter Kategori
|--------------------------------------------------------------------------
*/

if ($filter_kategori != '') {
    $filter_kategori = mysqli_real_escape_string($koneksi, $filter_kategori);

    $sql .= " AND aspirasi.id_kategori = '$filter_kategori'";
}

/*
|--------------------------------------------------------------------------
| Urutan
|--------------------------------------------------------------------------
*/

$sql .= " ORDER BY aspirasi.id_aspirasi DESC";

$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard Admin</title>

    <link rel="stylesheet" href="../asset/css/style.css">

    <style>

        /* MENU ADMIN */

        .menu-admin {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .menu-admin a {
            display: block;
            padding: 18px;
            border-radius: 16px;
            background: #f2f9fd;
            border: 1px solid #c1e5fc;
            color: #17547d;
            text-decoration: none;
            text-align: center;
            font-weight: bold;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu-admin a:hover {
            background: #e0f0fa;
            border-color: #39abf6;
            transform: translateY(-2px);
        }

        .menu-admin .logout {
            background: #fff5f5;
            border-color: #ffdede;
            color: #d95353;
        }

        .menu-admin .logout:hover {
            background: #ffeaea;
            border-color: #e05252;
        }


        /* STATISTIK */

        .statistik-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
            margin-bottom: 25px;
        }

        .stat-item {
            padding: 18px;
            border-radius: 16px;
            border: 1px solid #c1e5fc;
            background: #f2f9fd;
        }

        .stat-label {
            display: block;
            font-size: 13px;
            font-weight: bold;
            color: #5c6b7b;
            margin-bottom: 8px;
        }

        .stat-item strong {
            display: block;
            font-size: 28px;
            color: #17547d;
        }


        /* MENUNGGU */

        .stat-item.menunggu {
            background: #fffaf0;
            border-color: #f5dfaa;
        }

        .stat-item.menunggu strong {
            color: #b17a00;
        }


        /* DIPROSES */

        .stat-item.diproses {
            background: #eef8ff;
            border-color: #c1e5fc;
        }

        .stat-item.diproses strong {
            color: #168bd0;
        }


        /* SELESAI */

        .stat-item.selesai {
            background: #f0fbf5;
            border-color: #c9ecd8;
        }

        .stat-item.selesai strong {
            color: #278a55;
        }


        /* RESPONSIVE */

        @media (max-width: 800px) {

            .statistik-grid {
                grid-template-columns: repeat(2, 1fr);
            }

        }

        @media (max-width: 600px) {

            .menu-admin {
                grid-template-columns: 1fr;
            }

            .statistik-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }

            .stat-item {
                padding: 15px;
            }

            .stat-item strong {
                font-size: 24px;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <!-- HEADER -->

    <div class="header">

        <h2>Dashboard Admin</h2>

        <p>
            Selamat datang,
            <b><?php echo htmlspecialchars($_SESSION['nama']); ?></b>
        </p>

    </div>


    <!-- MENU -->

    <div class="card">

        <h3>Menu</h3>

        <div class="menu-admin">

            <a href="dashboard_admin.php">
                Daftar Pengaduan
            </a>

            <a href="kategori.php">
                Kelola Kategori
            </a>

            <a href="../controller/logout.php" class="logout">
                Logout
            </a>

        </div>

    </div>


    <!-- STATISTIK -->

    <div class="card statistik-card">

        <h3>Statistik Pengaduan</h3>

        <div class="statistik-grid">

            <div class="stat-item total">
                <span class="stat-label">Total Pengaduan</span>
                <strong><?php echo $total_pengaduan; ?></strong>
            </div>

            <div class="stat-item menunggu">
                <span class="stat-label">Menunggu</span>
                <strong><?php echo $total_menunggu; ?></strong>
            </div>

            <div class="stat-item diproses">
                <span class="stat-label">Diproses</span>
                <strong><?php echo $total_diproses; ?></strong>
            </div>

            <div class="stat-item selesai">
                <span class="stat-label">Selesai</span>
                <strong><?php echo $total_selesai; ?></strong>
            </div>

        </div>

        <h4>Pengaduan Berdasarkan Kategori</h4>

        <?php if (mysqli_num_rows($query_statistik_kategori) > 0) { ?>

            <div class="table-wrapper">

                <table>

                    <tr>
                        <th>No</th>
                        <th>Kategori</th>
                        <th>Jumlah Pengaduan</th>
                    </tr>

                    <?php

                    $no_kategori = 1;

                    while ($statistik = mysqli_fetch_assoc($query_statistik_kategori)) {

                    ?>

                        <tr>

                            <td>
                                <?php echo $no_kategori++; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($statistik['nama_kategori']); ?>
                            </td>

                            <td>
                                <?php echo $statistik['total']; ?>
                            </td>

                        </tr>

                    <?php } ?>

                </table>

            </div>

        <?php } else { ?>

            <p class="kosong">
                Belum ada kategori.
            </p>

        <?php } ?>

    </div>


    <!-- FILTER -->

    <div class="card">

        <h3>Filter Pengaduan</h3>

        <form method="GET" action="dashboard_admin.php">

            <label>Status:</label>

            <select name="status">

                <option value="">Semua Status</option>

                <option value="Menunggu"
                    <?php if ($filter_status == 'Menunggu') echo 'selected'; ?>>
                    Menunggu
                </option>

                <option value="Diproses"
                    <?php if ($filter_status == 'Diproses') echo 'selected'; ?>>
                    Diproses
                </option>

                <option value="Selesai"
                    <?php if ($filter_status == 'Selesai') echo 'selected'; ?>>
                    Selesai
                </option>

            </select>

            <br><br>

            <label>Kategori:</label>

            <select name="kategori">

                <option value="">Semua Kategori</option>

                <?php while ($kategori = mysqli_fetch_assoc($query_kategori)) { ?>

                    <option
                        value="<?php echo $kategori['id_kategori']; ?>"
                        <?php
                        if ($filter_kategori == $kategori['id_kategori']) {
                            echo 'selected';
                        }
                        ?>
                    >
                        <?php echo htmlspecialchars($kategori['nama_kategori']); ?>
                    </option>

                <?php } ?>

            </select>

            <br><br>

            <button type="submit">
                Filter
            </button>

            <a href="dashboard_admin.php">
                <button type="button">
                    Reset Filter
                </button>
            </a>

        </form>

    </div>


    <!-- DAFTAR PENGADUAN -->

    <div class="card">

        <h3>Daftar Pengaduan Siswa</h3>

        <?php if (mysqli_num_rows($query) > 0) { ?>

            <div class="table-wrapper">

                <table>

                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        <th>NIS</th>
                        <th>Kelas</th>
                        <th>Kategori</th>
                        <th>Judul</th>
                        <th>Isi Pengaduan</th>
                        <th>Foto</th>
                        <th>Tanggal</th>
                        <th>Status & Keterangan</th>
                    </tr>

                    <?php

                    $no = 1;

                    while ($row = mysqli_fetch_assoc($query)) {

                    ?>

                        <tr>

                            <td>
                                <?php echo $no++; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['nama_siswa']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['nis']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['kelas']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['nama_kategori']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['judul']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['isi_aspirasi']); ?>
                            </td>

                            <td>

                                <?php if (!empty($row['foto'])) { ?>

                                    <img
                                        src="../uploads/<?php echo htmlspecialchars($row['foto']); ?>"
                                        width="150"
                                        alt="Foto Kerusakan"
                                    >

                                    <br><br>

                                    <a
                                        href="../uploads/<?php echo htmlspecialchars($row['foto']); ?>"
                                        target="_blank"
                                    >
                                        Lihat Foto
                                    </a>

                                <?php } else { ?>

                                    Tidak ada foto

                                <?php } ?>

                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['tanggal']); ?>
                            </td>

                            <td>

                                <form action="../controller/update_status.php" method="POST">

                                    <input
                                        type="hidden"
                                        name="id_aspirasi"
                                        value="<?php echo $row['id_aspirasi']; ?>"
                                    >

                                    <select name="status" required>

                                        <option value="Menunggu"
                                            <?php if ($row['status'] == 'Menunggu') echo 'selected'; ?>>
                                            Menunggu
                                        </option>

                                        <option value="Diproses"
                                            <?php if ($row['status'] == 'Diproses') echo 'selected'; ?>>
                                            Diproses
                                        </option>

                                        <option value="Selesai"
                                            <?php if ($row['status'] == 'Selesai') echo 'selected'; ?>>
                                            Selesai
                                        </option>

                                    </select>

                                    <br><br>

                                    <textarea
                                        name="keterangan"
                                        rows="3"
                                        cols="25"
                                        placeholder="Tulis keterangan admin..."
                                    ></textarea>

                                    <br><br>

                                    <button type="submit">
                                        Simpan
                                    </button>

                                </form>

                            </td>

                        </tr>

                    <?php } ?>

                </table>

            </div>

        <?php } else { ?>

            <p class="kosong">
                Tidak ada pengaduan yang sesuai dengan filter.
            </p>

        <?php } ?>

    </div>

</div>

</body>

</html>