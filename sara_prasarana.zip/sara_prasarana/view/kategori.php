<?php

session_start();

include "../model/koneksi.php";

// Cek apakah yang login adalah admin
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Ambil data kategori
$query = mysqli_query(
    $koneksi,
    "SELECT * FROM kategori ORDER BY id_kategori ASC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Kategori</title>

    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>

    <div class="container">

        <!-- HEADER -->

        <div class="header">

            <h2>Kelola Kategori</h2>

            <p>
                Tambahkan dan kelola kategori pengaduan.
            </p>

            <a class="back" href="dashboard_admin.php">
                ← Kembali ke Dashboard Admin
            </a>

        </div>


        <!-- TAMBAH KATEGORI -->

        <div class="card">

            <h3>Tambah Kategori</h3>

            <form
                action="../controller/tambah_kategori.php"
                method="POST"
            >

                <label>
                    Nama Kategori
                </label>

                <input
                    type="text"
                    name="nama_kategori"
                    placeholder="Masukkan nama kategori"
                    required
                >

                <button type="submit">
                    + Tambah Kategori
                </button>

            </form>

        </div>


        <!-- DAFTAR KATEGORI -->

        <div class="card">

            <h3>Daftar Kategori</h3>

            <div class="table-wrapper">

                <table>

                    <thead>

                        <tr>
                            <th>No</th>
                            <th>ID Kategori</th>
                            <th>Nama Kategori</th>
                            <th>Aksi</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php

                        $no = 1;

                        if (mysqli_num_rows($query) > 0) {

                            while ($row = mysqli_fetch_assoc($query)) {

                        ?>

                                <tr>

                                    <td>
                                        <?php echo $no++; ?>
                                    </td>

                                    <td>
                                        <?php echo $row['id_kategori']; ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($row['nama_kategori']); ?>
                                    </td>

                                    <td>

                                        <a
                                            class="edit"
                                            href="edit_kategori.php?id=<?php echo $row['id_kategori']; ?>"
                                        >
                                            Edit
                                        </a>

                                        <a
                                            class="hapus"
                                            href="../controller/hapus_kategori.php?id=<?php echo $row['id_kategori']; ?>"
                                            onclick="return confirm('Yakin ingin menghapus kategori ini?');"
                                        >
                                            Hapus
                                        </a>

                                    </td>

                                </tr>

                        <?php

                            }

                        } else {

                        ?>

                            <tr>

                                <td colspan="4" class="kosong">
                                    Belum ada kategori.
                                </td>

                            </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</body>

</html>