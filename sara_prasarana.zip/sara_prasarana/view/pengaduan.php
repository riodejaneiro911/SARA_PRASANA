<?php

session_start();

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'siswa') {
    header("Location: login.php");
    exit;
}

include "../model/koneksi.php";

$kategori = mysqli_query($koneksi, "SELECT * FROM kategori");

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Buat Pengaduan</title>

    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>

    <div class="container">

        <div class="header">
            <h2>Buat Pengaduan</h2>
            <p>Laporkan masalah sarana dan prasarana sekolah.</p>
        </div>

        <div class="card">

            <form
                action="../controller/aspirasi.php"
                method="POST"
                enctype="multipart/form-data"
            >

                <label class="label">Kategori</label>

                <select name="id_kategori" required>

                    <option value="">
                        -- Pilih Kategori --
                    </option>

                    <?php while ($row = mysqli_fetch_assoc($kategori)) { ?>

                        <option value="<?php echo $row['id_kategori']; ?>">

                            <?php echo htmlspecialchars($row['nama_kategori']); ?>

                        </option>

                    <?php } ?>

                </select>

                <br><br>

                <label class="label">Judul Pengaduan</label>

                <input
                    type="text"
                    name="judul"
                    maxlength="100"
                    required
                >

                <br><br>

                <label class="label">Isi Pengaduan</label>

                <textarea
                    name="isi_aspirasi"
                    rows="6"
                    required
                ></textarea>

                <br><br>

                <label class="label">Foto Kerusakan</label>

                <input
                    type="file"
                    name="foto"
                    accept="image/jpeg,image/png,image/jpg"
                >

                <small>
                    Format yang diperbolehkan: JPG, JPEG, PNG
                </small>

                <br><br>

                <button type="submit">
                    Kirim Pengaduan
                </button>

            </form>

        </div>

        <a class="back" href="dashboard_siswa.php">
            ← Kembali ke Dashboard
        </a>

    </div>

</body>

</html>