<?php

session_start();

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'siswa') {
    header("Location: login.php");
    exit;
}

include "../model/koneksi.php";

$id_siswa = $_SESSION['id_siswa'];

$query = mysqli_query($koneksi, "
    SELECT 
        aspirasi.*,
        kategori.nama_kategori
    FROM aspirasi
    JOIN kategori 
        ON aspirasi.id_kategori = kategori.id_kategori
    WHERE aspirasi.id_siswa = '$id_siswa'
    ORDER BY aspirasi.id_aspirasi DESC
");

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Riwayat Pengaduan</title>

    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>

    <div class="container">

        <div class="header">
            <h2>Riwayat Pengaduan</h2>
            <p>Lihat pengaduan dan perkembangan prosesnya.</p>
        </div>

        <?php
        if (mysqli_num_rows($query) > 0) {

            while ($row = mysqli_fetch_assoc($query)) {

                $id_aspirasi = $row['id_aspirasi'];
        ?>

                <div class="card">

                    <h3>
                        <?php echo htmlspecialchars($row['judul']); ?>
                    </h3>

                    <p>
                        <b>Kategori:</b>
                        <?php echo htmlspecialchars($row['nama_kategori']); ?>
                    </p>

                    <p>
                        <b>Isi Pengaduan:</b><br>
                        <?php echo htmlspecialchars($row['isi_aspirasi']); ?>
                    </p>

                    <p>
                        <b>Tanggal:</b>
                        <?php echo htmlspecialchars($row['tanggal']); ?>
                    </p>

                    <p>
                        <b>Status Sekarang:</b>
                        <?php echo htmlspecialchars($row['status']); ?>
                    </p>

                    <p>
                        <a href="detail_pengaduan.php?id=<?php echo $id_aspirasi; ?>">
                            <button type="button">
                                Detail Pengaduan
                            </button>
                        </a>
                    </p>

                    <h4>Riwayat Proses</h4>

                    <?php

                    $history = mysqli_query($koneksi, "
                        SELECT *
                        FROM history
                        WHERE id_aspirasi = '$id_aspirasi'
                        ORDER BY id_history ASC
                    ");

                    if (mysqli_num_rows($history) > 0) {

                    ?>

                        <div class="table-wrapper">

                            <table>

                                <tr>
                                    <th>No</th>
                                    <th>Status</th>
                                    <th>Keterangan</th>
                                    <th>Tanggal</th>
                                </tr>

                                <?php

                                $no_history = 1;

                                while ($h = mysqli_fetch_assoc($history)) {

                                ?>

                                    <tr>

                                        <td>
                                            <?php echo $no_history++; ?>
                                        </td>

                                        <td>
                                            <?php echo htmlspecialchars($h['status']); ?>
                                        </td>

                                        <td>
                                            <?php
                                            echo htmlspecialchars(
                                                $h['keterangan'] !== null && $h['keterangan'] !== ''
                                                ? $h['keterangan']
                                                : '-'
                                            );
                                            ?>
                                        </td>

                                        <td>
                                            <?php echo htmlspecialchars($h['tanggal_history']); ?>
                                        </td>

                                    </tr>

                                <?php
                                }
                                ?>

                            </table>

                        </div>

                    <?php
                    } else {
                    ?>

                        <p class="kosong">
                            Belum ada riwayat proses.
                        </p>

                    <?php
                    }
                    ?>

                </div>

        <?php
            }
        } else {
        ?>

            <div class="card kosong">
                <p>Belum ada pengaduan.</p>
            </div>

        <?php
        }
        ?>

        <br>

        <a href="pengaduan.php">
            <button type="button">
                + Buat Pengaduan
            </button>
        </a>

        <br><br>

        <a class="back" href="dashboard_siswa.php">
            ← Kembali ke Dashboard
        </a>

    </div>

</body>

</html>