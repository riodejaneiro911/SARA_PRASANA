<?php

session_start();

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'siswa') {
    header("Location: login.php");
    exit;
}

include "../model/koneksi.php";

// Cek ID pengaduan
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: riwayat.php");
    exit;
}

$id_aspirasi = $_GET['id'];
$id_siswa = $_SESSION['id_siswa'];

// Ambil data pengaduan milik siswa yang sedang login
$query = mysqli_prepare($koneksi, "
    SELECT
        aspirasi.*,
        kategori.nama_kategori
    FROM aspirasi
    JOIN kategori
        ON aspirasi.id_kategori = kategori.id_kategori
    WHERE aspirasi.id_aspirasi = ?
    AND aspirasi.id_siswa = ?
");

mysqli_stmt_bind_param(
    $query,
    "ii",
    $id_aspirasi,
    $id_siswa
);

mysqli_stmt_execute($query);

$result = mysqli_stmt_get_result($query);

$data = mysqli_fetch_assoc($result);

mysqli_stmt_close($query);

// Kalau pengaduan tidak ditemukan
if (!$data) {
    echo "<script>
        alert('Pengaduan tidak ditemukan!');
        window.location='riwayat.php';
    </script>";
    exit;
}

// Ambil history pengaduan
$history = mysqli_prepare($koneksi, "
    SELECT
        history.*,
        admin.nama AS nama_admin
    FROM history
    JOIN admin
        ON history.id_admin = admin.id_admin
    WHERE history.id_aspirasi = ?
    ORDER BY history.id_history ASC
");

mysqli_stmt_bind_param(
    $history,
    "i",
    $id_aspirasi
);

mysqli_stmt_execute($history);

$result_history = mysqli_stmt_get_result($history);

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Pengaduan</title>

    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>

    <div class="container">

        <div class="header">
            <h2>Detail Pengaduan</h2>
            <p>Informasi lengkap pengaduan dan proses penanganannya.</p>
        </div>

        <div class="card">

            <h3>Informasi Pengaduan</h3>

            <p>
                <b>Kategori:</b><br>
                <?php echo htmlspecialchars($data['nama_kategori']); ?>
            </p>

            <p>
                <b>Judul Pengaduan:</b><br>
                <?php echo htmlspecialchars($data['judul']); ?>
            </p>

            <p>
                <b>Isi Pengaduan:</b><br>
                <?php echo nl2br(htmlspecialchars($data['isi_aspirasi'])); ?>
            </p>

            <p>
                <b>Tanggal:</b><br>
                <?php echo htmlspecialchars($data['tanggal']); ?>
            </p>

            <p>
                <b>Status Sekarang:</b><br>
                <?php echo htmlspecialchars($data['status']); ?>
            </p>

        </div>

        <div class="card">

            <h3>Foto Kerusakan</h3>

            <?php if (!empty($data['foto'])) { ?>

                <img
                    src="../uploads/<?php echo htmlspecialchars($data['foto']); ?>"
                    width="300"
                    alt="Foto Kerusakan"
                >

                <br><br>

                <a
                    href="../uploads/<?php echo htmlspecialchars($data['foto']); ?>"
                    target="_blank"
                >
                    Lihat Foto Ukuran Penuh
                </a>

            <?php } else { ?>

                <p class="kosong">
                    Tidak ada foto kerusakan.
                </p>

            <?php } ?>

        </div>

        <div class="card">

            <h3>Riwayat Proses</h3>

            <?php if (mysqli_num_rows($result_history) > 0) { ?>

                <div class="table-wrapper">

                    <table>

                        <tr>
                            <th>No</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Admin</th>
                            <th>Tanggal</th>
                        </tr>

                        <?php

                        $no = 1;

                        while ($h = mysqli_fetch_assoc($result_history)) {

                        ?>

                            <tr>

                                <td>
                                    <?php echo $no++; ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($h['status']); ?>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $h['keterangan'] !== null && $h['keterangan'] !== ''
                                        ? $h['keterangan']
                                        : '-'
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($h['nama_admin']); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($h['tanggal_history']); ?>
                                </td>

                            </tr>

                        <?php } ?>

                    </table>

                </div>

            <?php } else { ?>

                <p class="kosong">
                    Belum ada riwayat proses.
                </p>

            <?php } ?>

        </div>

        <a class="back" href="riwayat.php">
            ← Kembali ke Riwayat
        </a>

    </div>

</body>

</html>